#include <stdio.h>
#define SWAP(x,y,t) ((t)=(x), (x)=(y), (y)=(t))

int Partition(int list[], int left, int right)
{
	//�� ���Ŀ����� ���� �Լ�
	int pivot, temp;
	int low, high;

	low = left;
	high = right + 1;
	pivot = list[left];
	do {
		do {
			low++;
		}while(low <= right && list[low] < pivot);
		do {
			high--;
		}while(high >= left && list[high] > pivot);
		if(low < high) SWAP(list[low], list[high], temp);
	}while(low < high);

	SWAP(list[left], list[high], temp);
	return high;
}

void insertion_sort(int list[], int s, int e)
{
	//���� �ε��� s, �� �ε��� e�� �迭�� ���� ��������
	int i, j, key;
	for(i = s; i < e; i++)
	{
		key = list[i];
		for(j = i - 1; j >= 0 && list[j] > key; j--) 
			list[j+1] = list[j]; /* ���ڵ��� ������ �̵� */
		list[j+1] = key;
	}

}

void sort_Hybrid(int A[], int s, int e)

{
	//printf("sort_Hybrid(%d, %d)\n",s,e);
	if(s >= e)	return;
	if(e-s < 10)
	{
		insertion_sort(A,s,e);
		return;		
	}
	int m= Partition(A, s, e);
	sort_Hybrid(A, s, m-1);

	sort_Hybrid(A, m+1, e);

}

void main()
{
	int A[]={12,34,6,18,10,11,31,51,17,9,1,3,6,9,12,14,50,35,37,10,12,13};
	//	insertion_sort(A,0,21);
	sort_Hybrid(A,0,21);
	for(int i=0;i<=21;i++) printf("%d ",A[i]);
	printf("\n");
}